# API de Gerenciamento de Alunos para Escola de Idiomas

## Descrição

Esta aplicação API foi criada para gerenciar alunos, cursos e professores em uma escola de idiomas. Utiliza **FastAPI** para fornecer rotas que permitem as operações CRUD (Criar, Ler, Atualizar, Excluir).

## Como Instalar e Executar

1. Clone este repositório:
    ```bash
    git clone https://github.com/seu-usuario/alunos_api.git
    ```

2. Instale as dependências:
    ```bash
    pip install -r requirements.txt
    ```

3. Execute a aplicação:
    ```bash
    uvicorn main:app --reload
    ```

4. Acesse a documentação interativa da API em [http://localhost:8000/docs](http://localhost:8000/docs).

## Como Testar as Rotas com o Postman

1. Importe a coleção de rotas do Postman.
2. Teste todas as rotas descritas acima.
