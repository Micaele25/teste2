from fastapi import FastAPI
from routes.curso_routes import curso_router
from routes.aluno_routes import aluno_router

app = FastAPI(title="Sistema de Gerenciamento Educacional")

app.include_router(curso_router, prefix="/cursos", tags=["Cursos"])
app.include_router(aluno_router, prefix="/alunos", tags=["Alunos"])
