from pydantic import BaseModel

class Curso(BaseModel):
    id: int = None
    nome: str
    descricao: str
    carga_horaria: int
