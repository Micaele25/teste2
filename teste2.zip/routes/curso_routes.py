from fastapi import APIRouter, HTTPException
from typing import List
from models.curso import Curso

curso_router = APIRouter()
cursos = []  # Base de dados em memória

@curso_router.get("/", response_model=List[Curso])
def listar_cursos():
    return cursos

@curso_router.post("/", response_model=Curso)
def criar_curso(curso: Curso):
    curso.id = len(cursos) + 1
    cursos.append(curso)
    return curso
